###
### This program will estimate mean calibration.
###

### Set working directory
rm(list=ls())
setwd("/mnt/bmh01-rds/mrc-multi-outcome/Project_6")
getwd()

### Extract scenario from command line
args <- commandArgs(trailingOnly = T)
scen <- args[1]
print(paste("scen = ", scen, sep = ""))

### Load simulated data
load(paste("data/sim/large_sample_prep_data_", scen, ".RData", sep = ""))

### Load packages
source("code/z_functions.R")
source("code/z_load_packages.R")
source("code/p2/0_input_parameters.R")

### Choose number of bootstrap samples
CI.R.boot <- 100

###
### Estimate mean calibration using each of the approaches
###

###
### blr-ipcw
print(paste("START blr-ipcw", Sys.time()))
cl <- makeCluster(3)
registerDoParallel(3)
calib.mean.blr <-(foreach(input=1:3,
                          .packages=c("calibmsm")) %dopar%{
                            
                            if (scen == "C1"){
                              out <- calib_msm(data.mstate = data.mstate,
                                               data.raw = data.raw,
                                               j = 1,
                                               s = 0,
                                               t = t.eval,
                                               tp.pred = tp.pred[[input]],
                                               calib.type = "blr",
                                               CI = 95,
                                               CI.R.boot = CI.R.boot,
                                               assess.moderate = FALSE,
                                               assess.mean = TRUE) 
                            } else {
                              out <- calib_msm(data.mstate = data.mstate,
                                               data.raw = data.raw,
                                               j = 1,
                                               s = 0,
                                               t = t.eval,
                                               tp.pred = tp.pred[[input]],
                                               calib.type = "blr",
                                               w.covs = c("x12", "x13", "x15", "x24", "x25", "x34", "x35", "x45"),
                                               CI = 95,
                                               CI.R.boot = CI.R.boot,
                                               assess.moderate = FALSE,
                                               assess.mean = TRUE) 
                            }
                            
                            ### Return output
                            out
                          })
stopCluster(cl)
str(calib.mean.blr)


### Save output
save.image(paste("data/sim/large_sample_mean_", scen, ".RData", sep = ""))

###
### mlr-ipcw
print(paste("START mlr-ipcw", Sys.time()))
cl <- makeCluster(3)
registerDoParallel(3)
calib.mean.mlr <-(foreach(input=1:3, 
                         .packages=c("calibmsm")) %dopar%{
                           
                           if (scen == "C1"){
                             out <- calib_msm(data.mstate = data.mstate,
                                              data.raw = data.raw,
                                              j = 1,
                                              s = 0,
                                              t = t.eval,
                                              tp.pred = tp.pred[[input]],
                                              calib.type = "mlr",
                                              CI = 95,
                                              CI.R.boot = CI.R.boot,
                                              assess.moderate = FALSE,
                                              assess.mean = TRUE) 
                           } else {
                             out <- calib_msm(data.mstate = data.mstate,
                                              data.raw = data.raw,
                                              j = 1,
                                              s = 0,
                                              t = t.eval,
                                              tp.pred = tp.pred[[input]],
                                              calib.type = "mlr",
                                              w.covs = c("x12", "x13", "x15", "x24", "x25", "x34", "x35", "x45"),
                                              CI = 95,
                                              CI.R.boot = CI.R.boot,
                                              assess.moderate = FALSE,
                                              assess.mean = TRUE) 
                           }
                           
                           ### Return output
                           out
                         })
stopCluster(cl)
str(calib.mean.mlr)


### Save output
save.image(paste("data/sim/large_sample_mean_", scen, ".RData", sep = ""))

###
### Aalen-Johansen
print(paste("START AJ", Sys.time()))
cl <- makeCluster(3)
registerDoParallel(3)
calib.mean.aj <-(foreach(input=1:3, 
                         .packages=c("calibmsm")) %dopar%{
                           
                           if (scen == "C1"){
                             out <- calib_msm(data.mstate = data.mstate,
                                              data.raw = data.raw,
                                              j = 1,
                                              s = 0,
                                              t = t.eval,
                                              tp.pred = tp.pred[[input]],
                                              calib.type = "aj",
                                              CI = 95,
                                              CI.type = "bootstrap",
                                              CI.R.boot = CI.R.boot,
                                              assess.moderate = FALSE,
                                              assess.mean = TRUE) 
                           } else {
                             out <- calib_msm(data.mstate = data.mstate,
                                              data.raw = data.raw,
                                              j = 1,
                                              s = 0,
                                              t = t.eval,
                                              tp.pred = tp.pred[[input]],
                                              calib.type = "aj",
                                              pv.n.pctls = 20,
                                              CI = 95,
                                              CI.type = "bootstrap",
                                              CI.R.boot = CI.R.boot,
                                              assess.moderate = FALSE,
                                              assess.mean = TRUE) 
                           }
                           
                           ### Return output
                           out
                         })
stopCluster(cl)
str(calib.mean.aj)

### Save output
save.image(paste("data/sim/large_sample_mean_", scen, ".RData", sep = ""))
print("IMAGE SAVED")

