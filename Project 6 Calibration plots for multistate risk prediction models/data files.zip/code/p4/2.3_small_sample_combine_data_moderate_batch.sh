module load libs/gcc/gsl/2.5 apps/gcc/R/4.3.1 libs/gcc/nlopt/2.7.1 compilers/gcc/11.2.0
nohup Rscript 2.3_small_sample_combine_data_moderate.R C1 1500 10 > 2.3_small_sample_combine_data_moderate_C1_n1500_pctl10.out
nohup Rscript 2.3_small_sample_combine_data_moderate.R C2 1500 10 > 2.3_small_sample_combine_data_moderate_C2_n1500_pctl10.out
nohup Rscript 2.3_small_sample_combine_data_moderate.R C3 1500 10 > 2.3_small_sample_combine_data_moderate_C3_n1500_pctl10.out
nohup Rscript 2.3_small_sample_combine_data_moderate.R C1 3000 10 > 2.3_small_sample_combine_data_moderate_C1_n3000_pctl10.out
nohup Rscript 2.3_small_sample_combine_data_moderate.R C2 3000 10 > 2.3_small_sample_combine_data_moderate_C2_n3000_pctl10.out
nohup Rscript 2.3_small_sample_combine_data_moderate.R C3 3000 10 > 2.3_small_sample_combine_data_moderate_C3_n3000_pctl10.out